https://doc.lagout.org/operating%20system%20/linux/Learning%20the%20bash%20Shell%20-%20Unix%20Shell%20Programming.pdf

https://www.cs.purdue.edu/homes/grr/SystemsProgrammingBook/Book/Chapter5-WritingYourOwnShell.pdf

https://github.com/tokenrove/build-your-own-shell

https://danishpraka.sh/posts/write-a-shell/

https://brennan.io/2015/01/16/write-a-shell-in-c/

https://github.com/kamalmarhubi/shell-workshop

https://indradhanush.github.io/blog/writing-a-unix-shell-part-1/

https://www.cs.cornell.edu/courses/cs414/2004su/homework/shell/shell.html

https://gist.github.com/VideoCarp/d7cec2195a7de370d850aead62fa09cd

https://www.oreilly.com/library/view/bash-cookbook/0596526784/ch01s09.html

https://web.stanford.edu/class/cs111/spring22/proj_shell/

http://www.cs.loyola.edu/~jglenn/702/S2005/Examples/dup2.html
