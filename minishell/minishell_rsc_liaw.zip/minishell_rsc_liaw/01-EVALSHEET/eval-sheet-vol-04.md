# BONUS SECTION

## SECTION-1-AND-OR
-	test-1				:	use &&, || and parenthesis with commands 

## SECTION-2-WILDCARD
-	test-1				:	able to use wildcards in arguments (*)

## SECTION-3-QUOTES-HANDLING
-	test-1				:	"'$USER'" prints the value of USER variable
-	test-2				:	'"$USER"' prints the "$USER"